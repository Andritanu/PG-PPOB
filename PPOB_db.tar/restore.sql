--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.1
-- Dumped by pg_dump version 10.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.tb_level DROP CONSTRAINT tb_level_pkey;
ALTER TABLE ONLY public.tb_admin DROP CONSTRAINT tb_admin_pkey;
ALTER TABLE ONLY public.tarif DROP CONSTRAINT tarif_pkey;
ALTER TABLE ONLY public.tagihan DROP CONSTRAINT tagihan_pkey;
ALTER TABLE ONLY public.penggunaan DROP CONSTRAINT penggunaan_pkey;
ALTER TABLE ONLY public.pembayaran DROP CONSTRAINT pembayaran_pkey;
ALTER TABLE ONLY public.pelanggan DROP CONSTRAINT pelanggan_pkey;
DROP TABLE public.tb_level;
DROP TABLE public.tb_admin;
DROP TABLE public.tarif;
DROP TABLE public.tagihan;
DROP TABLE public.penggunaan;
DROP TABLE public.pembayaran;
DROP TABLE public.pelanggan;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: pelanggan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pelanggan (
    id_petugas integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nomor_kwh integer,
    nama_pelanggan character varying(50),
    alamat character varying(50),
    id_tarif integer
);


ALTER TABLE pelanggan OWNER TO postgres;

--
-- Name: pembayaran; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pembayaran (
    id_pembayaran integer NOT NULL,
    id_tagihan integer,
    id_pelanggan integer,
    tanggal_pembayaran date,
    bulan_bayar character varying(10),
    biaya_admin integer,
    total_admin integer,
    id_admin integer
);


ALTER TABLE pembayaran OWNER TO postgres;

--
-- Name: penggunaan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE penggunaan (
    id_penggunaan integer NOT NULL,
    id_pelanggan integer,
    bulan character varying(10),
    tahun character varying(5),
    meter_awal integer,
    meter_akhir integer
);


ALTER TABLE penggunaan OWNER TO postgres;

--
-- Name: tagihan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tagihan (
    id_tagihan integer NOT NULL,
    id_penggunaan integer,
    id_pelanggan integer,
    bulan character varying(10),
    tahun character varying(5),
    jumlah_meter integer,
    status character varying(15)
);


ALTER TABLE tagihan OWNER TO postgres;

--
-- Name: tarif; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tarif (
    id_tarif integer NOT NULL,
    daya integer,
    tarifperkwh integer
);


ALTER TABLE tarif OWNER TO postgres;

--
-- Name: tb_admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_admin (
    id_admin integer NOT NULL,
    username character varying(50),
    password character varying(50),
    nama_admin character varying(50),
    id_level integer
);


ALTER TABLE tb_admin OWNER TO postgres;

--
-- Name: tb_level; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE tb_level (
    id_level integer NOT NULL,
    nama character varying(50)
);


ALTER TABLE tb_level OWNER TO postgres;

--
-- Data for Name: pelanggan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pelanggan (id_petugas, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM stdin;
\.
COPY pelanggan (id_petugas, username, password, nomor_kwh, nama_pelanggan, alamat, id_tarif) FROM '$$PATH$$/2830.dat';

--
-- Data for Name: pembayaran; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_admin, id_admin) FROM stdin;
\.
COPY pembayaran (id_pembayaran, id_tagihan, id_pelanggan, tanggal_pembayaran, bulan_bayar, biaya_admin, total_admin, id_admin) FROM '$$PATH$$/2833.dat';

--
-- Data for Name: penggunaan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM stdin;
\.
COPY penggunaan (id_penggunaan, id_pelanggan, bulan, tahun, meter_awal, meter_akhir) FROM '$$PATH$$/2831.dat';

--
-- Data for Name: tagihan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM stdin;
\.
COPY tagihan (id_tagihan, id_penggunaan, id_pelanggan, bulan, tahun, jumlah_meter, status) FROM '$$PATH$$/2832.dat';

--
-- Data for Name: tarif; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tarif (id_tarif, daya, tarifperkwh) FROM stdin;
\.
COPY tarif (id_tarif, daya, tarifperkwh) FROM '$$PATH$$/2829.dat';

--
-- Data for Name: tb_admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM stdin;
\.
COPY tb_admin (id_admin, username, password, nama_admin, id_level) FROM '$$PATH$$/2828.dat';

--
-- Data for Name: tb_level; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tb_level (id_level, nama) FROM stdin;
\.
COPY tb_level (id_level, nama) FROM '$$PATH$$/2827.dat';

--
-- Name: pelanggan pelanggan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pelanggan
    ADD CONSTRAINT pelanggan_pkey PRIMARY KEY (id_petugas);


--
-- Name: pembayaran pembayaran_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pembayaran
    ADD CONSTRAINT pembayaran_pkey PRIMARY KEY (id_pembayaran);


--
-- Name: penggunaan penggunaan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY penggunaan
    ADD CONSTRAINT penggunaan_pkey PRIMARY KEY (id_penggunaan);


--
-- Name: tagihan tagihan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tagihan
    ADD CONSTRAINT tagihan_pkey PRIMARY KEY (id_tagihan);


--
-- Name: tarif tarif_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tarif
    ADD CONSTRAINT tarif_pkey PRIMARY KEY (id_tarif);


--
-- Name: tb_admin tb_admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_admin
    ADD CONSTRAINT tb_admin_pkey PRIMARY KEY (id_admin);


--
-- Name: tb_level tb_level_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tb_level
    ADD CONSTRAINT tb_level_pkey PRIMARY KEY (id_level);


--
-- PostgreSQL database dump complete
--

